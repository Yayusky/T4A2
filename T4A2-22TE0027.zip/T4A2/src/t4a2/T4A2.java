package t4a2;

import java.util.Scanner;

public class T4A2 {

    public static void main(String[] args) {
        //ejercicio1();
        //1.Dise?a una aplicaci?n que muestre las tablas de multiplicar del 1 al 10.
        //ejercicio2();
        //2.Realizar un programa en Java que pida un n?mero x, y nos diga cu?ntos n?meros hay entre 1 y x que son primos.
        //ejercicio3();
        //3.Realizar un programa en Java que pida un n?mero x, y nos diga cu?ntos n?meros hay entre 1 y x, cu?ntos pares y cu?ntos impares. 
        ejercicio4();
        //4.Un programa en Java que te permita ingresar una palabra y la imprima al rev?s.
    }

    public static void ejercicio1() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("GENERADOR DE TABLAS DE MULTIPLICAR");

        for (int i = 1; i < 11; i++) {

            System.out.println("TABLA DE " + i);

            for (int j = 1; j < 11; j++) {
                System.out.println(i + " x " + j + " = " + (i * j));
            }
        }
    }

    public static void ejercicio2() {

        int inicio, fin, contador = 0;

        Scanner sc = new Scanner(System.in);

        System.out.println("ESCRIBE EL PRIMER NUMERO:");
        inicio = sc.nextInt();
        System.out.println("ESCRIBE EL NUMERO FINAL:");
        fin = sc.nextInt();

        for (int x = inicio; x <= fin; x++) {
            if (esPrimo(x)) {
                contador++;
                System.out.print(String.valueOf(x) + ",");
            }
        }
        System.out.printf("\nTOTAL: %d \n", contador);
        sc.close();
    }

    public static boolean esPrimo(int numero) {

        if (numero == 0 || numero == 1 || numero == 4) {
            return false;
        }
        for (int x = 2; x < numero / 2; x++) {

            if (numero % x == 0) {
                return false;
            }
        }

        return true;
    }

    public static void ejercicio3() {

        Scanner scanner = new Scanner(System.in);

        int cant, num, pares = 0, impares = 0;
        System.out.print("CONTADOR DE NUMEROS PARES\n"
                + "CUANTOS NUMEROS DESEAS INGRESAR: ");
        cant = scanner.nextInt();

        for (int i = 1; i <= cant; i++) {
            System.out.print("INGRESA EL NUMERO " + i + " de " + cant + ": ");
            num = (new Scanner(System.in)).nextInt();

            if (num % 2 == 0) {
                pares++;
            } else {
                impares++;
            }
        }

        System.out.println("\nNUMEROS PARES: " + pares);
        System.out.println("NUMEROS IMPARES: " + impares);
    }

    public static void ejercicio4() {

        Scanner tec = new Scanner(System.in);
        String palabra;
        String invert = " ";

        System.out.print("GENERADOR DE PALABRAS AL REVES :)\n"
                + "Ingrese una palabra que deseas poner al reves: ");
        palabra = tec.nextLine();

        for (int contador = palabra.length() - 1; contador >= 0; contador--) {
            invert = invert + palabra.charAt(contador);

        }
        System.out.println(invert);

    }

}
